insert into policy_details(id, policy_no, first_name, last_name, age, email, address1, address2, address3, plan)
values('1','1234567890' ,'fuser1', 'luser1', 28, 'abc@mail.com',  'Blk123, Streetname1 ','#12-23', 'Singapore-560032','MHC1');
insert into policy_details(id, policy_no, first_name, last_name, age, email, address1, address2, address3, plan)
values('2','7004567890' ,'aaa', 'bbb', 28, 'abc@mail.com',  'Blk123, Streetname1 ','#12-23', 'Singapore-560032','MHC1');