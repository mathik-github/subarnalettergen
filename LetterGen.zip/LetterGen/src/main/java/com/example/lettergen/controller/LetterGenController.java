package com.example.lettergen.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.example.lettergen.service.AWSS3Service;
import com.example.lettergen.service.LetterGenService;

@RestController
public class LetterGenController {

	@Autowired
	private LetterGenService letterGenService;

	@Autowired
	private AWSS3Service awsS3Service;

	@Autowired
	AmazonS3 amazonS3Client;
	@Value("${aws.s3.bucket}")
	private String bucketName;

	@Value("${output.folder.path}")
	private String outputPath;

	final MultipartFile multipartFile = null;

	@RequestMapping(value = "/generatePDF", params = "policyNo")
	public ResponseEntity<String> generatePDF(@RequestParam("policyNo") String policyNo) {

		File file = letterGenService.generatePDF(policyNo);

		try {

			amazonS3Client.putObject(new PutObjectRequest(bucketName, file.getName(), file));

		} catch (AmazonServiceException ase) {
			System.out.println("Ams exp error ");
		} catch (AmazonClientException ace) {
			System.out.println("AMS client error ");

		}

		final String response = "[" + file.getName() + "] PDF uploaded  successfully.";

		System.out.println(response);

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/**
	 * Download the file
	 *
	 * @param fileName fileName
	 * @return ByteArrayResource
	 */
	@GetMapping(path = "/download")
	public ResponseEntity<ByteArrayResource> downloadFile(@RequestParam("fileName") final String fileName) {
		try {
			final byte[] data = awsS3Service.downloadFile(fileName);
			final ByteArrayResource resource = new ByteArrayResource(data);
			return ResponseEntity.ok().contentLength(data.length).header("Content-type", "application/octet-stream")
					.header("Content-disposition", "attachment; filename=\"" + fileName + "\"")
					.header("Cache-Control", "no-cache").body(resource);
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
		return ResponseEntity.badRequest().contentLength(0).body(null);
	}
}
