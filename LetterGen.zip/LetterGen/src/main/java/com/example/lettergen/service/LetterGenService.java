package com.example.lettergen.service;

import java.io.File;

public interface LetterGenService {

    public File generatePDF(String policyNo);
}
