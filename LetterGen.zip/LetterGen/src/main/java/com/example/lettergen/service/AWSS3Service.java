package com.example.lettergen.service;

public interface AWSS3Service {

	byte[] downloadFile(String keyName);

}
