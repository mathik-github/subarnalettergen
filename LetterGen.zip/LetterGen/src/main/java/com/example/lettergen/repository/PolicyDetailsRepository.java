package com.example.lettergen.repository;

import com.example.lettergen.domain.PolicyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PolicyDetailsRepository extends JpaRepository<PolicyDetails, Long> {
    @Query(value = "SELECT * FROM policy_details a WHERE a.policy_no = ?1", nativeQuery = true)
    public List<PolicyDetails> findByPolicyNo(String policyNo);
}
