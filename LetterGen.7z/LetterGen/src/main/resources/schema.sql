DROP TABLE IF EXISTS policy_details;

CREATE TABLE policy_details
(
  id INT NOT NULL AUTO_INCREMENT,
  policy_no VARCHAR(50) NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  age INT NOT NULL,
  email VARCHAR(50) NOT NULL,
  address1 VARCHAR(50) NOT NULL,
  address2 VARCHAR(50) NOT NULL,
  address3 VARCHAR(50) NOT NULL,
  plan VARCHAR(50) NOT NULL,
  PRIMARY KEY (id)
);
