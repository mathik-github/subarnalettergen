package com.example.lettergen.controller;

import com.example.lettergen.service.LetterGenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class LetterGenController {
    @Autowired
    private LetterGenService letterGenService;

    @RequestMapping(value = "/generatePDF", params = "policyNo")
    public void generatePDF(@RequestParam("policyNo") String policyNo) {
        letterGenService.generatePDF(policyNo);
    }
}
