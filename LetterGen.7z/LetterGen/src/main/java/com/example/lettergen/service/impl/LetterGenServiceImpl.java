package com.example.lettergen.service.impl;

import com.example.lettergen.domain.PolicyDetails;
import com.example.lettergen.repository.PolicyDetailsRepository;
import com.example.lettergen.service.LetterGenService;
import com.lowagie.text.DocumentException;
import com.sun.scenario.effect.light.SpotLight;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class LetterGenServiceImpl implements LetterGenService {
	@Value("${output.folder.path}")
	private String outputPath;

	@Autowired
	private PolicyDetailsRepository policyDetailsRepository;

	@Override
	public void generatePDF(String policyNo) {
		String html = parseThymeleafTemplate(policyNo);
		try{
			generatePdfFromHtml(policyNo, html);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void generatePdfFromHtml(String policyNo, String html) throws IOException {
		ITextRenderer renderer = new ITextRenderer();
		renderer.setDocumentFromString(html);
		renderer.layout();

		long unixTime = System.currentTimeMillis();

		String outputFileName = outputPath+policyNo+"_"+unixTime+".pdf";
		// Create PDF with PDFBox
		try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
			// Generate the PDF
			renderer.createPDF(os);
			os.close();

			PDDocument pdfDoc = PDDocument.load(os.toByteArray());
			pdfDoc.save(outputFileName);
			pdfDoc.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		System.out.println("PDF created successfully.");
	}

	private String parseThymeleafTemplate(String policyNo) {
		List<PolicyDetails> policyDetailsList = policyDetailsRepository.findByPolicyNo(policyNo);
		PolicyDetails policyDetails = policyDetailsList.get(0);
		String name = policyDetails.getFirstName()+" "+policyDetails.getLastName();

		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String dateStr = formatter.format(date);

		ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
		templateResolver.setPrefix("/templates/");
		templateResolver.setSuffix(".html");
		templateResolver.setTemplateMode(TemplateMode.HTML);

		TemplateEngine templateEngine = new TemplateEngine();
		templateEngine.setTemplateResolver(templateResolver);
		Context context = new Context();
		context.setVariable("LetterDate", dateStr);
		context.setVariable("NAME", name);
		context.setVariable("ADDRESS1", policyDetails.getAddress1());
		context.setVariable("ADDRESS2", policyDetails.getAddress2());
		context.setVariable("ADDRESS3", policyDetails.getAddress3());
		context.setVariable("TITLE", "Renewal Letter");
		context.setVariable("PolicyNo", policyNo);
		context.setVariable("MainPlanName", policyDetails.getPlan());		
		context.setVariable("FREETEXT", "We refer to our Renewal Invitation letter requesting for your premium payment.");
		context.setVariable("FREETEXT1", "As we have not heard from you regarding this, we are unable to continue the insurance coverage and your\r\n" + 
				"		policy has been terminated as at 01 Mar 2020.");
				context.setVariable("FREETEXT2", "If you have any questions, please contact our customer service officers at 6332 1133 or email us at\r\n" + 
						"		healthcare@income.com.sg. We would be most happy to help you.");
				String html = templateEngine.process("LetterTemplate", context);
				return html;
	}
}
