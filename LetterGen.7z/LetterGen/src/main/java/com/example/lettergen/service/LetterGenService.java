package com.example.lettergen.service;

import java.io.IOException;

public interface LetterGenService {

    public void generatePDF(String policyNo);
}
