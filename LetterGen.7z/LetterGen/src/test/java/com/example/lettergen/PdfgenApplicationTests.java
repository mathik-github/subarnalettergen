package com.example.lettergen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfgenApplicationTests {

	@Test
	void contextLoads() {
	}

}
